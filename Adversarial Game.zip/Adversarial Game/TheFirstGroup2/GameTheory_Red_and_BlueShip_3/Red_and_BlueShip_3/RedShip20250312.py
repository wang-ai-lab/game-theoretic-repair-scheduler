import numpy as np
import random
import pandas as pd
import time  # 引入时间模块

class RedShip:
    def __init__(self):
        """初始化红方舰船"""
        # 舰船基本参数
        self.length = 304  # 米
        self.width = 75    # 米
        self.height = 60   # 米

        # 初始化装备节点信息
        self.nodes = self.initialize_nodes()
        self.efficiency_levels = {node_id: 5 for node_id in self.nodes}  # 初始全部节点完好

        # 初始化重要度矩阵
        self.importance_matrix = self.initialize_importance_matrix()

        # 初始化作战型与防御型节点能力
        self.combat_capabilities = self.initialize_combat_capabilities()
        self.defense_capabilities = self.initialize_defense_capabilities()

        # 初始化效能等级矩阵 (E) 以及毁伤矩阵 (E_Destroy) 和恢复矩阵 (E_Recovery)
        self.efficiency_matrix = {node_id: 5 for node_id in self.nodes}  # 初始状态全部为 5
        self.E_Destroy = {node_id: 0 for node_id in self.nodes}  # 初始无毁伤
        self.E_Recovery = {node_id: 0 for node_id in self.nodes}  # 初始无恢复

        # 确保所有节点初始化（70 个）
        self.E_Destroy = {i: 0 for i in range(70)}

    def initialize_nodes(self):
        """初始化 70 个装备节点"""
        node_data = {
            0: (30.2, 46.5, 50.1, 1, 2, 5, 40.0),
            1: (46.0, 46.2, 38.4, 1, 1, 6, 60.0),
            2: (80.2, 46.5, 44.5, 2, 3, 4, 86.0),
            3: (102.4, 25.1, 29.0, 2, 2, 5, 44.0),
            4: (104.4, 61.9, 22.7, 3, 2, 4, 48.0),
            5: (116.6, 61.2, 10.5, 2, 3, 3, 54.0),
            6: (149.0, 30.0, 4.9, 2, 1, 3, 62.0),
            7: (151.0, 69.4, 30.9, 2, 2, 2, 60.0),
            8: (182.4, 75.0, 41.6, 3, 1, 4, 40.0),
            9: (182.4, 61.9, 49.8, 3, 6, 4, 38.0),
            10: (182.4, 5.6, 30.6, 5, 2, 3, 76.0),
            11: (185.4, 66.6, 8.9, 2, 1, 3, 66.0),
            12: (187.0, 71.3, 39.9, 1, 1, 2, 46.0),
            13: (194.6, 66.6, 10.1, 1, 2, 2, 56.0),
            14: (205.2, 62.9, 9.9, 1, 4, 2, 46.0),
            15: (205.2, 66.6, 50.5, 3, 2, 3, 48.0),
            16: (205.2, 59.1, 16.6, 2, 2, 3, 76.0),
            17: (205.0, 59.0, 36.1, 2, 3, 3, 54.0),
            18: (220.4, 5.6, 45.1, 3, 1, 2, 54.0),
            19: (240.2, 69.4, 17.9, 3, 2, 2, 64.0),
            20: (253.3, 26.3, 54.4, 2, 3, 3, 54.0),
            21: (273.6, 61.9, 12.2, 2, 3, 3, 54.0),
            22: (276.6, 61.9, 51.1, 2, 2, 2, 60.0),
            23: (281.2, 61.9, 53.2, 2, 3, 4, 54.0),
            24: (285.8, 61.9, 26.1, 2, 2, 5, 44.0),
            25: (290.4, 15.0, 46.6, 2, 3, 5, 54.0),
            26: (295.0, 15.0, 13.4, 2, 3, 2, 70.0),
            27: (149.0, 46.9, 39.1, 1, 3, 5, 50.0),
            28: (148.0, 38.0, 16.5, 1, 2, 3, 72.0),
            29: (133.8, 13.1, 2.5, 2, 1, 3, 66.0),
            30: (155.1, 13.1, 39.1, 1, 2, 3, 72.0),
            31: (171.8, 13.1, 38.4, 2, 3, 3, 86.0),
            32: (199.1, 5.6, 20.0, 2, 2, 3, 76.0),
            33: (214.4, 13.1, 36.1, 3, 3, 3, 90.0),
            34: (222.0, 5.6, 45.1, 2, 3, 3, 54.0),
            35: (226.6, 13.1, 36.7, 1, 2, 3, 40.0),
            36: (252.4, 5.6, 12.2, 2, 1, 2, 50.0),
            37: (223.4, 66.6, 40.0, 1, 2, 2, 56.0),
            38: (223.4, 63.1, 41.4, 3, 2, 3, 48.0),
            39: (229.5, 66.6, 34.7, 3, 1, 3, 38.0),
            40: (235.6, 70.1, 17.8, 2, 2, 2, 60.0),
            41: (235.6, 63.1, 43.9, 3, 5, 4, 38.0),
            42: (152.0, 69.4, 9.5, 2, 1, 2, 50.0),
            43: (174.8, 60.0, 9.4, 2, 3, 4, 54.0),
            44: (187.0, 60.0, 5.9, 1, 1, 3, 62.0),
            45: (199.1, 60.0, 29.5, 2, 3, 3, 86.0),
            46: (211.3, 60.0, 50.0, 3, 3, 3, 90.0),
            47: (223.4, 60.0, 53.9, 1, 2, 4, 40.0),
            48: (255.4, 67.5, 3.4, 1, 1, 4, 30.0),
            49: (264.5, 18.8, 2.1, 3, 1, 3, 70.0),
            50: (200.1, 10.6, 20.0, 2, 2, 3, 72.0),
            51: (200.4, 10.1, 36.1, 3, 3, 3, 80.0),
            52: (222.0, 5.6, 45.1, 2, 3, 3, 64.0),
            53: (222.6, 13.1, 36.7, 1, 2, 3, 60.0),
            54: (222.4, 5.6, 12.2, 2, 1, 2, 40.0),
            55: (223.4, 66.6, 40.0, 1, 2, 2, 56.0),
            56: (223.4, 63.1, 41.4, 3, 2, 3, 48.0),
            57: (229.5, 66.6, 34.7, 3, 1, 3, 38.0),
            58: (235.6, 70.1, 17.8, 2, 2, 2, 60.0),
            59: (235.6, 73.1, 43.9, 3, 1, 4, 38.0),
            60: (152.0, 72.4, 9.5, 2, 1, 2, 50.0),
            61: (174.8, 70.0, 9.4, 2, 3, 4, 54.0),
            62: (187.0, 70.0, 5.9, 1, 2, 3, 62.0),
            63: (199.1, 60.0, 30.5, 2, 3, 3, 86.0),
            64: (211.3, 50.0, 30.0, 3, 3, 3, 90.0),
            65: (223.4, 60.0, 50.9, 1, 2, 4, 40.0),
            66: (255.4, 67.5, 50.4, 1, 5, 4, 30.0),
            67: (264.5, 18.8, 52.1, 3, 1, 3, 70.0),
            68: (200.1, 62.0, 30.5, 2, 3, 3, 86.0),
            69: (210.3, 62.0, 30.0, 3, 3, 3, 90.0)
        }

        node_types = {
            "基础节点": list(range(0, 9)),
            "雷达探测": list(range(10, 14)),
            "声纳探测": list(range(15, 19)),
            "防空导弹": list(range(20, 24)),
            "近防火炮": list(range(25, 29)),
            "反潜导弹": list(range(30, 34)),
            "电子战": list(range(35, 45)),
            "指挥控制": list(range(46, 55)),
            "信息作战": list(range(56, 65)),
            "次要节点": list(range(66, 69)),
        }

        nodes = {}
        for node_id, (x, y, z, part_a, part_b, part_c, repair_time) in node_data.items():
            node_type = next((t for t, ids in node_types.items() if node_id in ids), "未分类")
            nodes[node_id] = {
                "坐标": (x, y, z),
                "维修需求": {"A": part_a, "B": part_b, "C": part_c},
                "维修时间": repair_time,
                "类型": node_type,
            }
        return nodes

    def initialize_importance_matrix(self):
        """初始化完整的战时重要度矩阵（70 个节点）"""
        importance_data = {
            0: [5, 5, 5, 6, 5, 5, 5, 6, 5, 6],
            1: [4, 6, 5, 5, 6, 6, 6, 6, 6, 6],
            2: [4, 6, 6, 6, 5, 5, 6, 5, 6, 6],
            3: [4, 6, 6, 6, 5, 5, 5, 6, 5, 5],
            4: [5, 5, 5, 5, 5, 5, 6, 6, 6, 5],
            5: [6, 6, 5, 6, 5, 6, 6, 5, 5, 5],
            6: [4, 5, 5, 5, 5, 5, 6, 6, 6, 5],
            7: [6, 6, 6, 5, 5, 6, 6, 6, 5, 5],
            8: [3, 5, 6, 5, 6, 5, 6, 6, 6, 5],
            9: [5, 5, 6, 6, 6, 5, 6, 6, 6, 5],
            10: [3, 5, 1, 1, 4, 5, 5, 6, 5, 6],
            11: [5, 6, 2, 1, 4, 6, 5, 6, 5, 6],
            12: [2, 6, 2, 1, 4, 6, 5, 5, 5, 6],
            13: [3, 6, 2, 2, 3, 5, 5, 5, 6, 6],
            14: [2, 5, 2, 2, 3, 5, 5, 5, 6, 6],
            15: [3, 6, 2, 4, 4, 4, 3, 3, 3, 3],
            16: [3, 6, 2, 4, 4, 3, 3, 3, 3, 3],
            17: [2, 6, 1, 2, 3, 3, 3, 4, 4, 4],
            18: [1, 6, 1, 2, 3, 4, 4, 4, 4, 4],
            19: [2, 6, 2, 2, 4, 4, 4, 4, 4, 5],
            20: [1, 6, 3, 1, 2, 5, 5, 4, 6, 5],
            21: [3, 5, 2, 1, 2, 5, 5, 4, 6, 5],
            22: [3, 5, 1, 2, 2, 5, 5, 4, 6, 5],
            23: [3, 6, 2, 1, 2, 5, 5, 4, 6, 5],
            24: [3, 6, 3, 1, 2, 5, 5, 4, 6, 5],
            25: [3, 2, 5, 5, 6, 3, 3, 5, 3, 3],
            26: [3, 2, 6, 5, 6, 3, 3, 5, 3, 3],
            27: [4, 2, 6, 5, 6, 3, 3, 5, 3, 3],
            28: [2, 2, 5, 5, 6, 3, 3, 5, 3, 3],
            29: [1, 3, 6, 5, 6, 3, 3, 5, 3, 3],
            30: [2, 6, 2, 1, 2, 2, 2, 1, 2, 2],
            31: [2, 6, 1, 1, 2, 2, 2, 1, 2, 2],
            32: [1, 6, 1, 1, 2, 2, 2, 1, 2, 2],
            33: [2, 5, 1, 1, 2, 2, 2, 1, 2, 2],
            34: [1, 5, 1, 1, 2, 2, 2, 1, 2, 2],
            35: [3, 5, 5, 6, 5, 5, 2, 5, 2, 2],
            36: [3, 5, 6, 6, 5, 5, 2, 5, 2, 2],
            37: [5, 5, 6, 5, 6, 6, 3, 5, 2, 3],
            38: [5, 5, 5, 5, 5, 5, 1, 5, 2, 3],
            39: [5, 5, 5, 6, 5, 5, 1, 5, 2, 2],
            40: [5, 5, 6, 6, 6, 6, 2, 5, 2, 2],
            41: [5, 5, 5, 5, 5, 6, 2, 5, 2, 2],
            42: [4, 5, 5, 5, 5, 6, 2, 5, 2, 2],
            43: [4, 5, 5, 5, 5, 5, 2, 5, 2, 2],
            44: [4, 5, 5, 5, 5, 6, 2, 5, 2, 2],
            45: [5, 5, 5, 5, 5, 6, 2, 5, 2, 2],
            46: [6, 5, 6, 5, 6, 5, 5, 6, 6, 6],
            47: [4, 5, 6, 5, 6, 5, 5, 6, 6, 6],
            48: [4, 5, 6, 5, 6, 5, 5, 6, 6, 6],
            49: [4, 5, 6, 5, 6, 5, 5, 6, 6, 6],
            50: [3, 5, 5, 5, 5, 5, 5, 5, 5, 5],
            51: [3, 5, 6, 5, 6, 5, 5, 6, 6, 6],
            52: [3, 5, 6, 5, 6, 5, 5, 6, 6, 6],
            53: [3, 5, 6, 5, 6, 5, 5, 6, 6, 6],
            54: [4, 5, 6, 5, 6, 5, 5, 6, 6, 6],
            55: [4, 5, 5, 5, 5, 5, 5, 5, 5, 5],
            56: [2, 2, 3, 3, 3, 5, 3, 5, 4, 4],
            57: [3, 2, 2, 2, 2, 5, 3, 5, 4, 3],
            58: [4, 3, 3, 3, 3, 6, 3, 5, 4, 3],
            59: [4, 2, 3, 2, 2, 6, 3, 5, 4, 4],
            60: [4, 2, 3, 2, 2, 5, 3, 5, 2, 4],
            61: [3, 2, 3, 2, 2, 6, 3, 5, 2, 3],
            62: [2, 2, 3, 2, 2, 6, 3, 5, 2, 3],
            63: [5, 2, 3, 2, 2, 6, 3, 6, 2, 3],
            64: [6, 2, 3, 2, 3, 6, 3, 6, 4, 3],
            65: [1, 2, 3, 2, 2, 6, 3, 6, 3, 3],
            66: [2, 2, 3, 3, 2, 3, 2, 3, 3, 3],
            67: [2, 2, 2, 3, 2, 3, 2, 3, 3, 3],
            68: [3, 2, 3, 3, 2, 3, 2, 3, 3, 3],
            69: [2, 3, 3, 3, 2, 3, 2, 2, 3, 3],
        }
        columns = [
            "基础重要度", "鱼雷", "无人艇", "大型舰艇", "小型舰艇",
            "飞机/导弹", "轰炸机", "无人机", "固定翼战机", "武装直升机"
        ]
        return pd.DataFrame.from_dict(importance_data, orient="index", columns=columns)

    def initialize_combat_capabilities(self):
        """初始化作战型节点的能力"""
        return {
            10: 0.85, 11: 0.84, 12: 0.86, 13: 0.82, 14: 0.86,  # 雷达探测能力
            15: 0.55, 16: 0.65, 17: 0.60, 18: 0.70, 19: 0.65,  # 声纳探测能力
            20: 0.78, 21: 0.76, 22: 0.82, 23: 0.88, 24: 0.85,  # 防空导弹拦截能力
            25: 0.80, 26: 0.74, 27: 0.88, 28: 0.89, 29: 0.85,  # 近防火炮拦截能力
            30: 0.56, 31: 0.58, 32: 0.42, 33: 0.56, 34: 0.42,  # 反潜导弹拦截能力
        }

    def initialize_defense_capabilities(self):
        """初始化防御型节点的能力"""
        return {
            35: 0.76, 36: 0.78, 37: 0.86, 38: 0.82, 39: 0.70,  # 电子战干扰能力
            40: 0.82, 41: 0.80, 42: 0.82, 43: 0.78, 44: 0.80,  # 电子战继续
            45: 0.82, 46: 0.80, 47: 0.65, 48: 0.68, 49: 0.70,  # 指挥控制能力
            50: 0.65, 51: 0.86, 52: 0.80, 53: 0.72, 54: 0.80, 55: 0.75,  # 指挥继续
            56: 0.60, 57: 0.80, 58: 0.76, 59: 0.68, 60: 0.80,  # 信息作战能力
            61: 0.70, 62: 0.64, 63: 0.72, 64: 0.80, 65: 0.52  # 信息作战继续
        }

    def calculate_wartime_importance(self, node_id, attack_types):
        """
        计算节点的战时重要度 Wartime_Z_i
        :param node_id: 需要计算的重要度的节点编号
        :param attack_types: 当前波次的攻击类型列表
        :return: Wartime_Z_i 值
        """
        if node_id not in self.importance_matrix.index:
            raise ValueError(f"节点 {node_id} 不存在！")
        if not attack_types:
            return 0
        importance_values = []
        for attack_type in attack_types:
            if attack_type in self.importance_matrix.columns:
                importance_values.append(self.importance_matrix.at[node_id, attack_type])
            else:
                raise ValueError(f"未知攻击类型 {attack_type}，请检查攻击类型列表！")
        wartime_importance = sum(importance_values) / len(attack_types)
        return wartime_importance

    def display_status(self):
        """显示当前舰船状态，包括毁伤和恢复信息"""
        print("\n🚢 红方舰船状态:")
        for node_id, node in self.nodes.items():
            print(f"节点 {node_id} ({node['类型']}): 效能 {self.efficiency_matrix[node_id]}/5, 毁伤 {self.E_Destroy[node_id]}, 恢复 {self.E_Recovery[node_id]}")

    def apply_damage(self, damage_report):
        """
        根据当前战斗损伤情况更新效能等级矩阵 E 和毁伤矩阵 E_Destroy
        :param damage_report: 字典 {node_id: damage_value}
        """
        for node_id, damage in damage_report.items():
            if node_id in self.efficiency_matrix:
                self.E_Destroy[node_id] += damage
                self.efficiency_matrix[node_id] = max(0, self.efficiency_matrix[node_id] - damage)

    def apply_recovery(self, recovery_report):
        """
        根据当前维修情况更新效能等级矩阵 E 和恢复矩阵 E_Recovery
        :param recovery_report: 字典 {node_id: recovery_value}
        """
        for node_id, recovery in recovery_report.items():
            if node_id in self.efficiency_matrix:
                self.E_Recovery[node_id] += recovery
                self.efficiency_matrix[node_id] = min(5, self.efficiency_matrix[node_id] + recovery)

    def apply_repair(self, repair_teams=5, max_iter=50, ALPHA=1.0, BETA=2.0, RHO=0.1, Q=100.0, opponent_belief=0.5, gamma=1.0):
        """
        红方维修采用蚁群算法，同时利用对手恢复预估调整节点重要度
        """
        print("\n🔧 红方：使用蚁群算法优化维修路径（博弈调整版）...")
        repair_nodes = [nid for nid, dmg in self.E_Destroy.items() if dmg > 0]
        if not repair_nodes:
            print("⚠️ 红方：没有需要维修的节点。")
            return

        positions = np.array([self.nodes[nid]['坐标'] for nid in repair_nodes])
        num = len(repair_nodes)
        dmat = np.zeros((num, num))
        for i in range(num):
            for j in range(num):
                dmat[i, j] = np.linalg.norm(positions[i]-positions[j]) if i != j else np.inf

        pheromone = np.ones((num, num))
        imp = np.array([self.importance_matrix.loc[nid, "基础重要度"] for nid in repair_nodes])
        # 调整重要度，根据对手恢复预估
        adj_imp = imp * (1 + gamma * (opponent_belief - 0.5))

        best_path = None
        best_score = -np.inf

        for _ in range(max_iter):
            paths = []
            scores = []
            for _ in range(repair_teams):
                visited = []
                cur = random.randint(0, num-1)
                visited.append(cur)
                while len(visited) < num:
                    cur = visited[-1]
                    probs = np.zeros(num)
                    for j in range(num):
                        if j not in visited:
                            attr = (adj_imp[j] ** BETA) / (dmat[cur, j] + 1e-6)
                            probs[j] = (pheromone[cur, j] ** ALPHA) * attr
                    if probs.sum() == 0:
                        break
                    probs /= probs.sum()
                    nxt = np.random.choice(range(num), p=probs)
                    visited.append(nxt)
                paths.append(visited)
                tot_imp = adj_imp[visited].sum()
                tot_dist = sum(dmat[visited[i], visited[i+1]] for i in range(len(visited)-1))
                score = tot_imp / (tot_dist + 1e-6)
                scores.append(score)
                if score > best_score:
                    best_score = score
                    best_path = visited
            pheromone *= (1 - RHO)
            for path in paths:
                tot_dist = sum(dmat[path[i], path[i+1]] for i in range(len(path)-1))
                if tot_dist == 0:
                    continue
                delta = Q / tot_dist
                for i in range(len(path)-1):
                    pheromone[path[i], path[i+1]] += delta
                    pheromone[path[i+1], path[i]] += delta

        best_order = [repair_nodes[i] for i in best_path]
        print(f"🚑 红方最优维修路径: {best_order}")
        for nid in best_order:
            rec = min(1, self.E_Destroy[nid])
            self.apply_recovery({nid: rec})
        self.display_status()

    def calculate_combat_recovery_rate(self):
        """计算红方舰船的作战能力恢复率"""
        if not self.E_Destroy:
            return 100.0
        total_nodes = len(self.E_Destroy)
        damaged_nodes = sum(1 for damage in self.E_Destroy.values() if damage > 0)
        recovery_rate = ((total_nodes - damaged_nodes) / total_nodes) * 100
        return recovery_rate

    def process_attacks(self, attacks, repair_teams=5):
        """
        处理红方舰船受到的攻击，并在每波攻击后进行维修
        :param attacks: 由 generate_multiple_attacks() 生成的攻击链
        :param repair_teams: 维修小组数量
        """
        print("\n🔥 发生战斗，处理攻击...")
        current_time = 0  # 单位：分钟
        for wave_id, wave in enumerate(attacks):
            print(f"\n🌊 第 {wave_id + 1} 波攻击 , 当前时间: {current_time} 分钟")
            damage_report = {}
            for attack in wave:
                node_id, tnt_q, x_q, y_q, z_q, attack_type = attack
                damage_value = min(5, tnt_q // 500)  # 限制伤害值最大为 5
                if damage_value > 0:
                    damage_report[node_id] = damage_value
                print(f"  🚀 攻击 {node_id}，TNT 当量: {tnt_q} kg, 伤害值: {damage_value}")
            self.apply_damage(damage_report)
            self.display_status()
            # 检查是否有损伤节点需要维修
            need_repair = any(self.E_Destroy[node_id] > 0 for node_id in self.E_Destroy)
            if need_repair:
                print("\n🔧 开始维修...")
                self.apply_repair(repair_teams)
            current_time += 30  # 模拟 30 分钟间隔
            time.sleep(1)

def generate_attack(attack_type, num_attacks):
    attacks = []
    if attack_type == "鱼雷":
        seq_range = (20, 25)
        tnt_range = (1600, 2000)
        z_range = (0, 20)
    elif attack_type == "无人艇":
        seq_range = (41, 50)
        tnt_range = (200, 500)
        z_range = (0, 5)
    elif attack_type == "大型舰艇":
        seq_range = (51, 60)
        tnt_range = (1000, 1500)
        z_range = (0, 0)
    elif attack_type == "小型舰艇":
        seq_range = (61, 69)
        tnt_range = (100, 300)
        z_range = (0, 0)
    elif attack_type == "飞机/导弹":
        seq_range = (0, 9)
        tnt_range = (600, 900)
        z_range = (20, 60)
    elif attack_type == "轰炸机":
        seq_range = (36, 40)
        tnt_range = (1400, 1800)
        z_range = (100, 150)
    elif attack_type == "无人机":
        seq_range = (10, 19)
        tnt_range = (30, 80)
        z_range = (10, 40)
    elif attack_type == "固定翼战机":
        seq_range = (26, 29)
        tnt_range = (800, 1200)
        z_range = (60, 100)
    elif attack_type == "武装直升机":
        seq_range = (30, 35)
        tnt_range = (500, 900)
        z_range = (20, 80)
    else:
        return attacks

    for _ in range(num_attacks):
        n_q = random.randint(*seq_range)
        tnt_q = random.randint(*tnt_range) * 0.8
        x_q = random.randint(0, 300)
        y_q = random.randint(0, 70)
        z_q = random.randint(*z_range)
        attacks.append((n_q, tnt_q, x_q, y_q, z_q, attack_type))
    return attacks

def generate_multiple_attacks(num_waves=5):
    """
    生成多波次攻击，每一波都包含所有武器类型
    :param num_waves: 攻击波数
    :return: 攻击链列表
    """
    attack_types = {
        "鱼雷": 5,
        "无人艇": 10,
        "大型舰艇": 5,
        "小型舰艇": 5,
        "飞机/导弹": 5,
        "轰炸机": 5,
        "无人机": 15,
        "固定翼战机": 5,
        "武装直升机": 5
    }
    attack_chain = []
    for wave in range(num_waves):
        wave_attacks = []
        for attack_type, num_attacks in attack_types.items():
            wave_attacks.extend(generate_attack(attack_type, num_attacks))
        attack_chain.append(wave_attacks)
    return attack_chain

if __name__ == "__main__":
    red_ship = RedShip()
    red_ship.display_status()
    # 生成攻击链
    attack_chain = generate_multiple_attacks()
    # 处理攻击（包含战斗和维修）
    red_ship.process_attacks(attack_chain)
