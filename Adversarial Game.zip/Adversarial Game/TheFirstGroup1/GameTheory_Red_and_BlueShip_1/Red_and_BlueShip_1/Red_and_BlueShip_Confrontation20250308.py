import time
import numpy as np
from RedShip20250308 import RedShip, generate_multiple_attacks as generate_red_attacks
from BlueShip20250308 import BlueShip, generate_multiple_attacks as generate_blue_attacks

class NavalWarfareGame:
    def __init__(self, num_rounds=1, repair_teams=3):
        """ 初始化红蓝双方舰船以及博弈参数 """
        self.red_ship = RedShip()
        self.blue_ship = BlueShip()
        self.num_rounds = num_rounds  # 交战回合数
        self.repair_teams = repair_teams  # 维修小组数

    def process_wave(self, wave_id, red_wave, blue_wave, current_time):
        """
        同时处理红蓝双方在同一波次的攻击
        :param wave_id: 当前波次编号（从0开始）
        :param red_wave: 红方本波次攻击列表（对蓝方）
        :param blue_wave: 蓝方本波次攻击列表（对红方）
        :param current_time: 当前时间（分钟）
        """
        print(f"\n===== 波次 {wave_id + 1}，当前时间: {current_time} 分钟 =====")

        # 分别构造双方的损伤报告
        red_to_blue_damage = {}  # 红方对蓝方的攻击
        blue_to_red_damage = {}  # 蓝方对红方的攻击

        print("\n🚀 红方发动攻击：")
        for attack in red_wave:
            node_id, tnt_q, x_q, y_q, z_q, attack_type = attack
            damage_value = min(5, tnt_q // 500)
            if damage_value > 0:
                red_to_blue_damage[node_id] = damage_value
            print(f"  攻击节点 {node_id}，TNT 当量: {tnt_q} kg, 伤害值: {damage_value}")

        print("\n🔵 蓝方发动攻击：")
        for attack in blue_wave:
            node_id, tnt_q, x_q, y_q, z_q, attack_type = attack
            damage_value = min(5, tnt_q // 500)
            if damage_value > 0:
                blue_to_red_damage[node_id] = damage_value
            print(f"  攻击节点 {node_id}，TNT 当量: {tnt_q} kg, 伤害值: {damage_value}")

        # 同时更新双方损伤
        self.blue_ship.apply_damage(red_to_blue_damage)
        self.red_ship.apply_damage(blue_to_red_damage)

        # 输出本波次损伤总和
        red_inflicted = sum(red_to_blue_damage.values())
        blue_inflicted = sum(blue_to_red_damage.values())
        print(f"\n📊 本波次：红方对蓝方造成的总伤害: {red_inflicted}")
        print(f"📊 本波次：蓝方对红方造成的总伤害: {blue_inflicted}")

        # 显示双方当前状态
        print("\n🚢 蓝方当前状态：")
        self.blue_ship.display_status()
        print("\n🚢 红方当前状态：")
        self.red_ship.display_status()

        # 互为反馈（这里仅打印反馈信息，后续可根据反馈调整攻击和防御策略）
        threshold = 10  # 例如：伤害超过10则视为“重创”
        if red_inflicted > threshold:
            print("反馈：蓝方受到重创，红方未来攻击将更集中于关键节点。")
        if blue_inflicted > threshold:
            print("反馈：红方受到重创，蓝方未来将加强防御或调整打击目标。")

        # 模拟时间推进
        time.sleep(1)
        return current_time + 30

    def play_round(self, round_num):
        """ 进行单轮战斗：生成攻击、按波次同时处理、维修和输出统计 """
        print(f"\n===== ⚔️  第 {round_num + 1} 轮战斗开始 ⚔️ =====")

        # 1️⃣ 生成双方攻击链（列表，每个元素代表一波攻击）
        red_attacks = generate_red_attacks()  # 红方对蓝方攻击
        blue_attacks = generate_blue_attacks()  # 蓝方对红方攻击

        # 确保双方波次数一致（否则按最小波次数处理）
        num_waves = min(len(red_attacks), len(blue_attacks))
        current_time = 0

        # 2️⃣ 按波次同时处理攻击
        for wave_id in range(num_waves):
            current_time = self.process_wave(wave_id, red_attacks[wave_id], blue_attacks[wave_id], current_time)

        # 3️⃣ 计算双方作战能力恢复率
        red_combat_recovery = self.red_ship.calculate_combat_recovery_rate()
        blue_combat_recovery = self.blue_ship.calculate_combat_recovery_rate()
        print(f"\n🔴 红方作战能力恢复率: {red_combat_recovery:.2f}%")
        print(f"🔵 蓝方作战能力恢复率: {blue_combat_recovery:.2f}%")

        # 4️⃣ 维修资源优化
        print("\n🔧 维修优化调整...")
        self.red_ship.apply_repair(self.repair_teams)
        self.blue_ship.apply_repair(self.repair_teams)

        # 5️⃣ 输出本轮损失统计
        red_damage = sum(self.red_ship.E_Destroy.values())
        blue_damage = sum(self.blue_ship.E_Destroy.values())
        print(f"\n📊 本轮战斗损失统计:")
        print(f"🔴 红方总损伤: {red_damage}")
        print(f"🔵 蓝方总损伤: {blue_damage}")

        time.sleep(1)

    def start_game(self):
        """ 开始多回合博弈 """
        print("\n===== ⚔️ 开始红蓝舰船对抗模拟 ⚔️ =====")
        for round_num in range(self.num_rounds):
            self.play_round(round_num)

        print("\n===== 🏆 战斗结束，计算最终胜负 🏆 =====")
        final_red_damage = sum(self.red_ship.E_Destroy.values())
        final_blue_damage = sum(self.blue_ship.E_Destroy.values())

        if final_red_damage < final_blue_damage:
            print("✅ 红方胜利！")
        elif final_blue_damage < final_red_damage:
            print("✅ 蓝方胜利！")
        else:
            print("🤝 平局！")

        # 计算摧毁的节点数
        red_destroyed = sum(1 for level in self.red_ship.efficiency_matrix.values() if level == 0)
        blue_destroyed = sum(1 for level in self.blue_ship.efficiency_matrix.values() if level == 0)
        print(f"\n📊 红方摧毁的节点数: {red_destroyed}")
        print(f"📊 蓝方摧毁的节点数: {blue_destroyed}")

        # 计算被摧毁节点的重要度之和
        red_destroyed_importance = sum(
            self.red_ship.importance_matrix.loc[node_id, "基础重要度"]
            for node_id, level in self.red_ship.efficiency_matrix.items() if level == 0
        )
        blue_destroyed_importance = sum(
            self.blue_ship.importance_matrix.loc[node_id, "基础重要度"]
            for node_id, level in self.blue_ship.efficiency_matrix.items() if level == 0
        )
        print(f"\n📊 红方被摧毁节点重要度之和: {red_destroyed_importance}")
        print(f"📊 蓝方被摧毁节点重要度之和: {blue_destroyed_importance}")

        # 使用综合重要度计算维修优先级
        red_attack_types = ["鱼雷", "无人艇", "大型舰艇", "小型舰艇",
                            "飞机/导弹", "轰炸机", "无人机", "固定翼战机", "武装直升机"]
        blue_attack_types = ["鱼雷", "无人艇", "大型舰艇", "飞机/导弹", "无人机"]

        red_repair_nodes = [node for node, damage in self.red_ship.E_Destroy.items() if damage > 0]
        blue_repair_nodes = [node for node, damage in self.blue_ship.E_Destroy.items() if damage > 0]

        red_dynamic_importance_sum = round(sum(
            self.red_ship.calculate_wartime_importance(node, red_attack_types) for node in red_repair_nodes
        ))
        blue_dynamic_importance_sum = round(sum(
            self.blue_ship.calculate_wartime_importance(node, blue_attack_types) for node in blue_repair_nodes
        ))

        print(f"\n🔧 红方维修的节点动态重要度之和: {red_dynamic_importance_sum}")
        print(f"🔧 蓝方维修的节点动态重要度之和: {blue_dynamic_importance_sum}")


# 运行博弈模拟
if __name__ == "__main__":
    game = NavalWarfareGame(num_rounds=1, repair_teams=3)
    game.start_game()
