import numpy as np
import random
import pandas as pd
import time  # 引入时间模块

class BlueShip:
    def __init__(self):
        """初始化蓝方舰船"""
        # 舰船基本参数
        self.length = 304  # 米
        self.width = 75    # 米
        self.height = 60   # 米

        # 初始化装备节点信息
        self.nodes = self.initialize_nodes()
        self.efficiency_levels = {node_id: 5 for node_id in self.nodes}  # 初始全部节点完好

        # 初始化重要度矩阵
        self.importance_matrix = self.initialize_importance_matrix()

        # 初始化作战型与防御型节点能力
        self.combat_capabilities = self.initialize_combat_capabilities()
        self.defense_capabilities = self.initialize_defense_capabilities()

        # 初始化效能等级矩阵 (E) 以及毁伤矩阵 (E_Destroy) 和恢复矩阵 (E_Recovery)
        self.efficiency_matrix = {node_id: 5 for node_id in self.nodes}  # 初始状态全部为 5
        self.E_Destroy = {node_id: 0 for node_id in self.nodes}  # 初始无毁伤
        self.E_Recovery = {node_id: 0 for node_id in self.nodes}  # 初始无恢复

        self.E_Destroy = {i: 0 for i in range(70)}  # 确保所有节点初始化

    def initialize_nodes(self):
        """ 初始化 70 个装备节点 """
        node_data = {
            0: (30.2, 40.5, 50.1, 1, 2, 5, 40.0),
            1: (50.0, 40.2, 38.4, 1, 2, 6, 70.0),
            2: (80.2, 50.5, 40.5, 2, 3, 4, 86.0),
            3: (80.4, 25.1, 29.0, 2, 5, 5, 50.0),
            4: (80.4, 61.9, 20.7, 3, 2, 4, 48.0),
            5: (100.6, 60.2, 10.5, 2, 3, 3, 54.0),
            6: (100.0, 70.0, 5.0, 1, 1, 3, 60.0),
            7: (120.0, 70.4, 30.9, 2, 2, 2, 60.0),
            8: (162.4, 72.0, 51.6, 3, 1, 4, 50.0),
            9: (162.4, 61.9, 50.8, 3, 1, 4, 38.0),
            10: (162.4, 5.6, 30.6, 2, 2, 3, 80.0),
            11: (185.4, 56.6, 10.9, 2, 1, 3, 66.0),
            12: (187.0, 71.3, 39.9, 1, 1, 2, 46.0),
            13: (200.6, 76.6, 10.1, 1, 2, 2, 56.0),
            14: (210.2, 72.9, 9.9, 1, 1, 2, 46.0),
            15: (210.2, 15.6, 50.5, 3, 2, 3, 50.0),
            16: (210.2, 59.1, 16.6, 2, 2, 3, 76.0),
            17: (210.0, 20.0, 36.1, 2, 3, 3, 54.0),
            18: (220.4, 20.6, 45.1, 3, 1, 2, 54.0),
            19: (240.2, 69.4, 17.9, 3, 2, 2, 64.0),
            20: (253.3, 26.3, 54.4, 2, 3, 3, 54.0),
            21: (273.6, 61.9, 12.2, 2, 3, 3, 54.0),
            22: (276.6, 61.9, 51.1, 2, 2, 2, 60.0),
            23: (281.2, 61.9, 53.2, 2, 3, 4, 54.0),
            24: (285.8, 61.9, 26.1, 2, 2, 5, 44.0),
            25: (290.4, 15.0, 46.6, 2, 3, 5, 54.0),
            26: (295.0, 15.0, 13.4, 3, 3, 2, 70.0),
            27: (149.0, 56.9, 39.1, 1, 3, 5, 50.0),
            28: (148.0, 38.0, 26.5, 1, 2, 3, 72.0),
            29: (133.8, 13.1, 6.5, 2, 1, 3, 66.0),
            30: (155.1, 13.1, 39.1, 1, 2, 3, 72.0),
            31: (171.8, 13.1, 38.4, 2, 3, 3, 86.0),
            32: (199.1, 5.6, 20.0, 2, 2, 3, 76.0),
            33: (214.4, 13.1, 36.1, 3, 3, 3, 90.0),
            34: (222.0, 5.6, 45.1, 2, 3, 3, 54.0),
            35: (226.6, 13.1, 36.7, 1, 2, 3, 40.0),
            36: (252.4, 5.6, 12.2, 2, 1, 2, 50.0),
            37: (223.4, 66.6, 40.0, 1, 2, 2, 56.0),
            38: (223.4, 63.1, 41.4, 3, 2, 3, 50.0),
            39: (229.5, 66.6, 17.7, 3, 1, 3, 38.0),
            40: (235.6, 70.1, 17.8, 2, 2, 2, 60.0),
            41: (235.6, 63.1, 43.9, 3, 1, 4, 40.0),
            42: (152.0, 69.4, 17.5, 2, 1, 2, 50.0),
            43: (174.8, 60.0, 17.4, 2, 3, 4, 54.0),
            44: (187.0, 60.0, 5.9, 1, 1, 3, 62.0),
            45: (199.1, 60.0, 29.5, 2, 3, 3, 86.0),
            46: (211.3, 60.0, 50.0, 3, 3, 3, 90.0),
            47: (223.4, 60.0, 53.9, 1, 2, 4, 40.0),
            48: (255.4, 67.5, 3.4, 1, 1, 4, 30.0),
            49: (264.5, 18.8, 2.1, 3, 1, 3, 70.0),
            50: (210.1, 52.0, 30.5, 2, 3, 3, 86.0),
            51: (240.3, 42.0, 30.0, 3, 3, 3, 90.0),
            52: (222.0, 5.6, 45.1, 2, 3, 3, 64.0),
            53: (222.6, 13.1, 36.7, 1, 2, 3, 60.0),
            54: (222.4, 15.6, 12.2, 2, 1, 2, 40.0),
            55: (223.4, 66.6, 40.0, 1, 2, 2, 56.0),
            56: (223.4, 63.1, 41.4, 3, 2, 3, 48.0),
            57: (229.5, 66.6, 34.7, 3, 1, 3, 38.0),
            58: (235.6, 70.1, 17.8, 2, 2, 2, 60.0),
            59: (235.6, 73.1, 43.9, 3, 1, 4, 38.0),
            60: (152.0, 72.4, 9.5, 2, 5, 2, 50.0),
            61: (174.8, 70.0, 9.4, 2, 3, 4, 54.0),
            62: (187.0, 70.0, 5.9, 1, 2, 3, 72.0),
            63: (199.1, 60.0, 30.5, 2, 3, 3, 86.0),
            64: (211.3, 50.0, 30.0, 3, 3, 3, 90.0),
            65: (223.4, 70.0, 50.9, 1, 2, 4, 40.0),
            66: (255.4, 67.5, 50.4, 1, 1, 4, 30.0),
            67: (264.5, 18.8, 52.1, 3, 1, 3, 70.0),
            68: (210.1, 52.0, 30.5, 2, 3, 3, 86.0),
            69: (240.3, 42.0, 30.0, 3, 3, 3, 90.0)
        }

        node_types = {
            "基础节点": list(range(0, 6)),
            "雷达探测": list(range(7, 12)),
            "声纳探测": list(range(13, 17)),
            "防空导弹": list(range(18, 22)),
            "近防火炮": list(range(23, 27)),
            "反潜导弹": list(range(28, 32)),
            "电子战": list(range(33, 42)),
            "指挥控制": list(range(43, 52)),
            "信息作战": list(range(53, 62)),
            "次要节点": list(range(63, 69)),
        }

        nodes = {}
        for node_id, (x, y, z, part_a, part_b, part_c, repair_time) in node_data.items():
            node_type = next((t for t, ids in node_types.items() if node_id in ids), "未知")
            nodes[node_id] = {
                "坐标": (x, y, z),
                "维修需求": {"A": part_a, "B": part_b, "C": part_c},
                "维修时间": repair_time,
                "类型": node_type,
            }
        return nodes

    def initialize_importance_matrix(self):
        """ 初始化完整的战时重要度矩阵（70 个节点） """
        importance_data = {
            0: [5, 5, 5, 6, 5, 6],
            1: [4, 6, 5, 5, 6, 6],
            2: [4, 6, 6, 6, 5, 5],
            3: [4, 6, 6, 6, 5, 6],
            4: [5, 5, 5, 5, 5, 6],
            5: [6, 6, 5, 6, 6, 5],
            6: [4, 5, 5, 5, 5, 6],
            7: [6, 3, 3, 3, 6, 6],
            8: [3, 2, 3, 2, 5, 6],
            9: [5, 2, 3, 2, 5, 6],
            10: [3, 2, 1, 1, 5, 6],
            11: [5, 3, 2, 1, 6, 6],
            12: [2, 3, 2, 1, 6, 5],
            13: [3, 6, 2, 2, 2, 3],
            14: [2, 5, 2, 2, 2, 3],
            15: [3, 6, 2, 4, 2, 3],
            16: [3, 6, 2, 4, 3, 3],
            17: [2, 6, 1, 2, 3, 4],
            18: [1, 1, 1, 2, 6, 4],
            19: [2, 1, 2, 2, 6, 4],
            20: [1, 2, 3, 1, 5, 4],
            21: [3, 2, 2, 1, 5, 4],
            22: [3, 2, 1, 2, 5, 4],
            23: [3, 6, 6, 5, 4, 6],
            24: [3, 6, 6, 5, 4, 6],
            25: [3, 5, 5, 5, 3, 5],
            26: [3, 5, 6, 5, 3, 5],
            27: [4, 5, 6, 5, 3, 5],
            28: [2, 6, 4, 3, 3, 2],
            29: [1, 5, 3, 3, 3, 2],
            30: [2, 6, 2, 1, 2, 1],
            31: [2, 6, 1, 1, 2, 1],
            32: [1, 6, 1, 1, 2, 1],
            33: [2, 3, 5, 5, 2, 6],
            34: [1, 3, 5, 5, 6, 6],
            35: [3, 3, 5, 6, 5, 5],
            36: [3, 3, 6, 6, 5, 5],
            37: [5, 3, 6, 5, 6, 5],
            38: [5, 2, 5, 5, 5, 5],
            39: [5, 2, 5, 6, 5, 5],
            40: [5, 2, 6, 6, 6, 5],
            41: [5, 2, 5, 5, 6, 5],
            42: [4, 2, 5, 5, 6, 5],
            43: [4, 5, 5, 5, 5, 5],
            44: [4, 5, 5, 5, 6, 5],
            45: [5, 5, 5, 5, 6, 5],
            46: [6, 5, 6, 5, 5, 6],
            47: [4, 5, 6, 5, 5, 6],
            48: [4, 5, 6, 5, 5, 6],
            49: [4, 5, 6, 5, 5, 6],
            50: [3, 5, 5, 5, 5, 5],
            51: [3, 5, 6, 5, 5, 6],
            52: [3, 5, 6, 5, 5, 6],
            53: [3, 4, 2, 2, 5, 6],
            54: [4, 1, 2, 3, 5, 6],
            55: [4, 1, 2, 3, 5, 5],
            56: [2, 2, 3, 3, 5, 5],
            57: [3, 2, 2, 2, 5, 5],
            58: [4, 3, 3, 3, 6, 5],
            59: [4, 2, 3, 2, 6, 5],
            60: [4, 2, 3, 2, 5, 5],
            61: [3, 2, 3, 2, 6, 5],
            62: [2, 2, 3, 2, 6, 5],
            63: [5, 2, 3, 2, 2, 2],
            64: [6, 2, 3, 2, 2, 2],
            65: [1, 2, 3, 2, 2, 2],
            66: [2, 2, 3, 3, 3, 3],
            67: [2, 2, 2, 3, 3, 3],
            68: [3, 2, 3, 3, 3, 3],
            69: [2, 3, 3, 3, 3, 2],
        }

        return pd.DataFrame.from_dict(
            importance_data,
            orient="index",
            columns=[
                "基础重要度", "鱼雷", "无人艇", "大型舰艇", "飞机/导弹", "无人机"
            ]
        )

    def initialize_combat_capabilities(self):
        """ 初始化作战型节点的能力 """
        return {
            7: 0.80, 8: 0.82, 9: 0.86, 10: 0.82, 11: 0.85, 12: 0.86,  # 雷达探测能力
            13: 0.56, 14: 0.60, 15: 0.65, 16: 0.62, 17: 0.68,          # 声纳探测能力
            18: 0.76, 19: 0.78, 20: 0.80, 21: 0.86, 22: 0.84,          # 防空导弹拦截能力
            23: 0.82, 24: 0.78, 25: 0.80, 26: 0.85, 27: 0.83,          # 近防火炮拦截能力
            28: 0.54, 29: 0.56, 30: 0.45, 31: 0.50, 32: 0.52,          # 反潜导弹拦截能力
        }

    def initialize_defense_capabilities(self):
        """ 初始化防御型节点的能力 """
        return {
            33: 0.75, 34: 0.74, 35: 0.86, 36: 0.82, 37: 0.75,  # 电子战干扰能力
            38: 0.82, 39: 0.80, 40: 0.81, 41: 0.78, 42: 0.86,
            43: 0.85, 44: 0.65, 45: 0.80, 46: 0.70, 47: 0.62,  # 指挥控制能力
            48: 0.63, 49: 0.60, 50: 0.55, 51: 0.86, 52: 0.65,
            53: 0.56, 54: 0.58, 55: 0.82, 56: 0.56, 57: 0.68,  # 信息作战能力
            58: 0.82, 59: 0.80, 60: 0.66, 61: 0.78, 62: 0.52
        }

    def calculate_wartime_importance(self, node_id, attack_types):
        """
        计算节点的战时重要度 Wartime_Z_i
        :param node_id: 需要计算的重要度的节点编号
        :param attack_types: 当前波次的攻击类型列表 (例如 ["鱼雷", "飞机/导弹"])
        :return: 计算出的 Wartime_Z_i 值
        """
        if node_id not in self.importance_matrix.index:
            raise ValueError(f"节点 {node_id} 不存在！")

        if not attack_types:
            return 0  # 没有攻击时，重要度为 0

        # 取出该节点在所有攻击类型下的重要度
        importance_values = []
        for attack_type in attack_types:
            if attack_type in self.importance_matrix.columns:
                importance_values.append(self.importance_matrix.at[node_id, attack_type])
            else:
                raise ValueError(f"未知攻击类型 {attack_type}，请检查攻击类型列表！")

        # 计算战时重要度 Wartime_Z_i
        wartime_importance = sum(importance_values) / len(attack_types)
        return wartime_importance

    def display_status(self):
        """ 显示当前舰船状态，包括毁伤和恢复信息 """
        print("\n🚢 蓝方舰船状态:")
        for node_id, node in self.nodes.items():
            print(f"节点 {node_id} ({node['类型']}): 效能 {self.efficiency_matrix[node_id]} /5, 毁伤 {self.E_Destroy[node_id]}, 恢复 {self.E_Recovery[node_id]}")

    def apply_damage(self, damage_report):
        """
        根据当前战斗损伤情况更新效能等级矩阵 E 和毁伤矩阵 E_Destroy
        :param damage_report: 字典 {node_id: damage_value}, damage_value 为本次攻击对节点的伤害
        """
        for node_id, damage in damage_report.items():
            if node_id in self.efficiency_matrix:
                self.E_Destroy[node_id] += damage  # 记录毁伤
                self.efficiency_matrix[node_id] = max(0, self.efficiency_matrix[node_id] - damage)  # 更新效能等级

    def apply_recovery(self, recovery_report):
        """
        根据当前维修情况更新效能等级矩阵 E 和恢复矩阵 E_Recovery
        :param recovery_report: 字典 {node_id: recovery_value}, recovery_value 为本次维修的恢复量
        """
        for node_id, recovery in recovery_report.items():
            if node_id in self.efficiency_matrix:
                self.E_Recovery[node_id] += recovery  # 记录恢复
                self.efficiency_matrix[node_id] = min(5, self.efficiency_matrix[node_id] + recovery)  # 更新效能等级

    def apply_repair(self, repair_teams=2):
        """
        根据毁伤程度和战时重要度，分配维修任务
        :param repair_teams: 维修小组数量
        """
        print("\n🔧 进行维修...")

        # 计算每个节点的修复优先级（毁伤程度 * 重要度总和）
        priority_list = []
        for node_id, damage in self.E_Destroy.items():
            if damage > 0:
                wartime_importance = sum(self.importance_matrix.loc[node_id])
                priority_score = damage * wartime_importance
                priority_list.append((node_id, priority_score))

        # 按优先级降序排列
        priority_list.sort(key=lambda x: x[1], reverse=True)

        # 维修小组依次修复最优先的节点
        repair_allocation = [[] for _ in range(repair_teams)]
        for idx, (node_id, _) in enumerate(priority_list):
            repair_allocation[idx % repair_teams].append(node_id)

        # 依次执行维修任务
        for team_id, assigned_nodes in enumerate(repair_allocation):
            print(f"🚑 维修小组 {team_id + 1} 修复: {assigned_nodes}")
            for node_id in assigned_nodes:
                repair_value = min(2, self.E_Destroy[node_id])  # 维修值不能超过毁伤值
                self.apply_recovery({node_id: repair_value})

        self.display_status()

    def calculate_combat_recovery_rate(self):
        """ 计算舰船的作战能力恢复率 """
        if not self.E_Destroy:
            return 100.0  # 如果没有毁伤，则恢复率为100%

        total_nodes = len(self.E_Destroy)
        damaged_nodes = sum(1 for damage in self.E_Destroy.values() if damage > 0)

        recovery_rate = ((total_nodes - damaged_nodes) / total_nodes) * 100
        return recovery_rate

    def process_attacks(self, attacks, repair_teams=2):
        """
        处理蓝方舰船受到的攻击，并在每波攻击后进行维修
        :param attacks: 由 generate_multiple_attacks() 生成的攻击链
        :param repair_teams: 维修小组数量
        """
        print("\n🔥 发生战斗，处理攻击...")

        current_time = 0  # 记录当前时间，单位：分钟

        for wave_id, wave in enumerate(attacks):
            print(f"\n🌊 第 {wave_id + 1} 波攻击 , 当前时间: {current_time} 分钟")

            damage_report = {}
            for attack in wave:
                node_id, tnt_q, x_q, y_q, z_q, attack_type = attack
                damage_value = min(5, tnt_q // 500)  # 伤害值限制在 0-5

                # 记录伤害值大于 0 的节点
                if damage_value > 0:
                    damage_report[node_id] = damage_value

                print(f"  🚀 攻击 {node_id}，TNT 当量: {tnt_q} kg, 伤害值: {damage_value}")

            # 处理损伤
            self.apply_damage(damage_report)
            self.display_status()  # 更新舰船状态

            # 检查是否需要维修
            need_repair = any(self.E_Destroy[node_id] > 1 for node_id in self.E_Destroy)
            if need_repair:
                print("\n🔧 **开始维修**")
                self.apply_repair(repair_teams)  # 调用维修

            # 新增：输出蓝方本波攻击总毁伤与蓝方累计毁伤
            blue_wave_damage = sum(damage_report.values())
            blue_cumulative_damage = sum(self.E_Destroy.values())
            print(f"\n【本波攻击统计】蓝方攻击总毁伤: {blue_wave_damage}；蓝方累计毁伤: {blue_cumulative_damage}")

            # 模拟 30 分钟攻击间隔
            current_time += 30  # 时间推进 30 分钟
            time.sleep(1)  # 现实中暂停 1 秒（可调），模拟间隔

# ========== 生成攻击链代码 ========== #
def generate_attack(attack_type, num_attacks):
    attacks = []
    if attack_type == "鱼雷":
        seq_range = (20, 29)
        tnt_range = (1500, 2000)
        z_range = (0, 10)
    elif attack_type == "无人艇":
        seq_range = (30, 59)
        tnt_range = (300, 500)
        z_range = (0, 5)
    elif attack_type == "大型舰艇":
        seq_range = (60, 69)
        tnt_range = (1200, 1500)
        z_range = (0, 0)
    elif attack_type == "飞机/导弹":
        seq_range = (0, 9)
        tnt_range = (500, 1000)
        z_range = (20, 80)
    elif attack_type == "无人机":
        seq_range = (10, 19)
        tnt_range = (30, 80)
        z_range = (10, 50)
    else:
        return attacks

    for _ in range(num_attacks):
        n_q = random.randint(*seq_range)
        tnt_q = random.randint(*tnt_range)
        x_q = random.randint(0, 300)
        y_q = random.randint(0, 70)
        z_q = random.randint(*z_range)
        attacks.append((n_q, tnt_q, x_q, y_q, z_q, attack_type))

    return attacks

def generate_multiple_attacks(num_waves=5):
    """
    生成多波次攻击，每一波都包含所有武器类型
    :param num_waves: 需要生成的攻击波次
    :return: 包含多个波次的攻击链
    """
    attack_types = {
        "鱼雷": 5,
        "无人艇": 10,
        "大型舰艇": 5,
        "飞机/导弹": 5,
        "无人机": 15
    }

    attack_chain = []
    for wave in range(num_waves):  # 生成 num_waves 波攻击
        wave_attacks = []  # 当前波次的所有攻击
        for attack_type, num_attacks in attack_types.items():
            wave_attacks.extend(generate_attack(attack_type, num_attacks))
        attack_chain.append(wave_attacks)  # 加入本波次攻击
    return attack_chain

# ========== 运行模拟 ========== #
if __name__ == "__main__":
    blue_ship = BlueShip()
    blue_ship.display_status()

    # 生成攻击链
    attack_chain = generate_multiple_attacks()

    # 处理攻击（战斗 + 维修）
    blue_ship.process_attacks(attack_chain)
