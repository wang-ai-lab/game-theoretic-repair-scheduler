import time
import numpy as np
from RedShip20250311 import RedShip, generate_multiple_attacks as generate_red_attacks
from BlueShip20250311 import BlueShip, generate_multiple_attacks as generate_blue_attacks


class NavalWarfareGame:
    def __init__(self, num_rounds=5, repair_teams=3):
        """初始化红蓝双方舰船以及博弈参数"""
        self.red_ship = RedShip()
        self.blue_ship = BlueShip()
        self.num_rounds = num_rounds  # 交战回合数
        self.base_repair_teams = repair_teams  # 基础维修小组数

        # 初始贝叶斯信念（用于估计对方战力恢复情况）
        self.red_bayesian = 0.5  # 红方对蓝方战力恢复的估计
        self.blue_bayesian = 0.5  # 蓝方对红方战力恢复的估计

        # 记录上一轮作战能力恢复率（用于贝叶斯更新）
        self.red_previous_recovery = None
        self.blue_previous_recovery = None

    def update_bayesian(self, old_belief, previous_recovery, current_recovery):
        """使用 Sigmoid 函数计算学习率，根据恢复率变化更新贝叶斯信念"""
        if previous_recovery is None:
            return current_recovery / 100.0
        observed_change = abs(current_recovery - previous_recovery)
        learning_rate = 1 / (1 + np.exp(-2 * observed_change))
        new_belief = (1 - learning_rate) * old_belief + learning_rate * (current_recovery / 100.0)
        return new_belief

    def play_round(self, round_num):
        """执行单轮战斗，逐波次处理攻击与维修并输出波次毁伤统计"""
        print(f"\n===== ⚔️  第 {round_num + 1} 轮战斗开始 ⚔️ =====")

        # 1️⃣ 生成双方攻击链（每个返回值是一个包含多波次攻击的列表）
        red_attacks = generate_red_attacks()   # 红舰对蓝舰攻击
        blue_attacks = generate_blue_attacks()  # 蓝舰对红舰攻击

        # 确保双方波次数一致
        num_waves = min(len(red_attacks), len(blue_attacks))
        current_time = 0

        # 计算红舰所有进攻性武器的平均目标威胁评估值
        # 假设 red_ship.threat_assessment 为红舰新增的属性（字典），记录各武器类型的目标威胁因子
        offensive_nodes = [node for node in self.red_ship.nodes.values()
                           if node["类型"] in self.red_ship.threat_assessment]
        if offensive_nodes:
            avg_threat = sum(self.red_ship.threat_assessment[node["类型"]] for node in offensive_nodes) / len(offensive_nodes)
        else:
            avg_threat = 1.0

        # 使用非线性减伤公式：当 avg_threat > 1 时，mitigation = (1/avg_threat)^3，否则为1
        mitigation = (1.0 / avg_threat) ** 3 if avg_threat > 1.0 else 1.0

        print(f"\n[调试] 红舰平均目标威胁: {avg_threat:.2f}, 红舰防御减伤系数: {mitigation:.2f}")

        for wave_id in range(num_waves):
            print(f"\n----- 波次 {wave_id + 1}，当前时间: {current_time} 分钟 -----")

            # 记录波次开始前的累计毁伤
            prev_red_damage = sum(self.red_ship.E_Destroy.values())
            prev_blue_damage = sum(self.blue_ship.E_Destroy.values())

            # 调整红舰发起的攻击：根据每个攻击的武器类型目标威胁因子放大 TNT 当量
            adjusted_red_attacks = []
            for attack in red_attacks[wave_id]:
                n_q, tnt_q, x_q, y_q, z_q, attack_type = attack
                threat_factor = self.red_ship.threat_assessment.get(attack_type, 1.0)
                adjusted_tnt = tnt_q * threat_factor
                adjusted_red_attacks.append((n_q, adjusted_tnt, x_q, y_q, z_q, attack_type))

            print("\n🚀 红方对蓝方发起攻击:")
            self.blue_ship.process_attacks([adjusted_red_attacks], repair_teams=self.base_repair_teams)

            # 蓝舰对红舰的攻击，蓝舰使用原始数据，
            # 但在红舰端临时覆盖 apply_damage 以按减伤系数降低实际收到的伤害
            print("\n🔵 蓝方对红方发起攻击:")
            original_apply_damage = self.red_ship.apply_damage

            def mitigated_apply_damage(damage_report, mitigation=mitigation):
                mitigated_report = {node: val * mitigation for node, val in damage_report.items()}
                original_apply_damage(mitigated_report)

            self.red_ship.apply_damage = mitigated_apply_damage
            self.red_ship.process_attacks([blue_attacks[wave_id]], repair_teams=self.base_repair_teams)
            self.red_ship.apply_damage = original_apply_damage

            # 记录波次结束后的累计毁伤
            current_red_damage = sum(self.red_ship.E_Destroy.values())
            current_blue_damage = sum(self.blue_ship.E_Destroy.values())

            # 计算本波新增毁伤
            wave_red_damage = current_red_damage - prev_red_damage
            wave_blue_damage = current_blue_damage - prev_blue_damage

            print(f"\n【波次 {wave_id + 1} 攻击统计】")
            print(f"  红方本波新增毁伤: {wave_red_damage}")
            print(f"  蓝方本波新增毁伤: {wave_blue_damage}")
            print(f"  红方累计毁伤: {current_red_damage}")
            print(f"  蓝方累计毁伤: {current_blue_damage}")

            current_time += 30
            time.sleep(1)

        # 2️⃣ 计算双方作战能力恢复率
        red_combat_recovery = self.red_ship.calculate_combat_recovery_rate()
        blue_combat_recovery = self.blue_ship.calculate_combat_recovery_rate()
        print(f"\n🔴 红方作战能力恢复率: {red_combat_recovery:.2f}%")
        print(f"🔵 蓝方作战能力恢复率: {blue_combat_recovery:.2f}%")

        # 3️⃣ 更新贝叶斯信念
        self.red_bayesian = self.update_bayesian(self.red_bayesian, self.red_previous_recovery, blue_combat_recovery)
        self.blue_bayesian = self.update_bayesian(self.blue_bayesian, self.blue_previous_recovery, red_combat_recovery)
        self.red_previous_recovery = blue_combat_recovery
        self.blue_previous_recovery = red_combat_recovery

        # 4️⃣ 动态调整维修小组数量
        red_repair_teams = max(1, int(round(self.base_repair_teams * (1 + (self.blue_bayesian - 0.5)))))
        blue_repair_teams = max(1, int(round(self.base_repair_teams * (1 + (self.red_bayesian - 0.5)))))
        print(f"\n🔧 红方分配维修小组数: {red_repair_teams}")
        print(f"🔧 蓝方分配维修小组数: {blue_repair_teams}")

        # 5️⃣ 维修资源优化
        print("\n🔧 红方开始维修...")
        self.red_ship.apply_repair(red_repair_teams)
        print("\n🔧 蓝方开始维修...")
        self.blue_ship.apply_repair(blue_repair_teams)

        # 6️⃣ 输出本轮最终累计统计
        final_red_damage = sum(self.red_ship.E_Destroy.values())
        final_blue_damage = sum(self.blue_ship.E_Destroy.values())
        print(f"\n📊 本轮战斗最终累计统计:")
        print(f"  红方累计毁伤: {final_red_damage}")
        print(f"  蓝方累计毁伤: {final_blue_damage}")

        # 7️⃣ 统计摧毁的节点数
        red_destroyed = sum(1 for level in self.red_ship.efficiency_matrix.values() if level == 0)
        blue_destroyed = sum(1 for level in self.blue_ship.efficiency_matrix.values() if level == 0)
        print(f"\n📊 红方摧毁的节点数: {red_destroyed}")
        print(f"📊 蓝方摧毁的节点数: {blue_destroyed}")

        # 8️⃣ 输出被摧毁节点的基础重要度之和
        red_destroyed_importance = sum(
            self.red_ship.importance_matrix.loc[node_id, "基础重要度"]
            for node_id, level in self.red_ship.efficiency_matrix.items() if level == 0
        )
        blue_destroyed_importance = sum(
            self.blue_ship.importance_matrix.loc[node_id, "基础重要度"]
            for node_id, level in self.blue_ship.efficiency_matrix.items() if level == 0
        )
        print(f"\n📊 红方被摧毁节点基础重要度之和: {red_destroyed_importance}")
        print(f"📊 蓝方被摧毁节点基础重要度之和: {blue_destroyed_importance}")

        # 9️⃣ 输出当前维修节点的动态重要度之和
        red_attack_types = ["鱼雷", "无人艇", "大型舰艇", "小型舰艇", "飞机/导弹", "轰炸机", "无人机", "固定翼战机", "武装直升机"]
        blue_attack_types = ["鱼雷", "无人艇", "大型舰艇", "飞机/导弹", "无人机"]
        red_repair_nodes = [node for node, damage in self.red_ship.E_Destroy.items() if damage > 0]
        blue_repair_nodes = [node for node, damage in self.blue_ship.E_Destroy.items() if damage > 0]
        red_dynamic_importance_sum = round(sum(
            self.red_ship.calculate_wartime_importance(node, red_attack_types) for node in red_repair_nodes
        ))
        blue_dynamic_importance_sum = round(sum(
            self.blue_ship.calculate_wartime_importance(node, blue_attack_types) for node in blue_repair_nodes
        ))
        print(f"\n🔧 红方维修的节点动态重要度之和: {red_dynamic_importance_sum}")
        print(f"🔧 蓝方维修的节点动态重要度之和: {blue_dynamic_importance_sum}")

        time.sleep(1)

    def start_game(self):
        """开始多回合战斗并计算最终胜负"""
        print("\n===== ⚔️ 开始红蓝舰船对抗模拟 ⚔️ =====")
        for round_num in range(self.num_rounds):
            self.play_round(round_num)

        print("\n===== 🏆 战斗结束，计算最终胜负 🏆 =====")
        final_red_damage = sum(self.red_ship.E_Destroy.values())
        final_blue_damage = sum(self.blue_ship.E_Destroy.values())

        if final_red_damage < final_blue_damage:
            print("✅ 红方胜利！")
        elif final_blue_damage < final_red_damage:
            print("✅ 蓝方胜利！")
        else:
            print("🤝 平局！")


# 运行博弈模拟
if __name__ == "__main__":
    game = NavalWarfareGame(num_rounds=1, repair_teams=3)
    game.start_game()
